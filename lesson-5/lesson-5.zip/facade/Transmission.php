<?php


class Transmission
{
    public $transmisssion;

    /**
     * @return string
     */
    public function getTransmisssion()
    {
        echo 'Automat' . PHP_EOL;
    }
}