<?php


class Engine
{
    public $engine;

    /**
     * @return string
     */
    public function getEngine()
    {
        echo '1.8' . PHP_EOL;
    }
}