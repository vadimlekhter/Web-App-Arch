<?php


class Color
{
    public $color;

    /**
     * @return string
     */
    public function getColor()
    {
        echo 'Black' . PHP_EOL;
    }
}