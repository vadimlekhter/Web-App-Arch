<?php


namespace components;

class BurgerComponent extends AbstractComponent
{
    /**
     * @return mixed|void
     */
    public function operation()
    {
        echo 'Бургер ';
    }
}