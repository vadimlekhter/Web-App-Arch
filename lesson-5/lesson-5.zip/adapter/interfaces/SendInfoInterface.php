<?php

namespace interfaces;

interface SendInfoInterface
{
    public function sendInfo(string $message);
}